<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>MPM</title>
	<link rel="stylesheet" href="css/materialize.min.css">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link rel="stylesheet" href="css/style.css">

	<!-- favicon -->
	<link rel="apple-touch-icon" sizes="180x180" href="assets/favicons/apple-touch-icon.png">
	<link rel="icon" type="image/png" sizes="32x32" href="assets/favicons/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/favicons/favicon-16x16.png">
	<link rel="manifest" href="assets/favicons/manifest.json">
	<link rel="mask-icon" href="assets/favicons/safari-pinned-tab.svg" color="#00aff0">
	<meta name="theme-color" content="#ffffff">
</head>
<body>
<div class="navbar-fixed">
	<nav>
	    <div class="nav-wrapper">
	      <a href="#" class="brand-logo center"><img src="assets/MPM_Logo Group_White.png"></a>
	      <!-- <ul class="left">
	        <li><a href="#">Assesment Sample</a></li>
	      </ul> -->
	      <!-- <ul class="right timer">
	        <li><a href="#"><p id="time_left"></p></a></li>
	      </ul> -->
	    </div>
  	</nav>
</div>