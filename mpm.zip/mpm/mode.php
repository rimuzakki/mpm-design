
<?php require_once('inc/header.inc.php');
require_once('inc/db.inc.php');
session_start();
?>
<section id="mode">
<div class="container" >
	<div class="row" >
		<div class="col s12" >
			<div class="card">
				<div class="card-content">
					
				
					<?php $result = $pdo->prepare('SELECT nilaiwpt,nilaiCfit from user WHERE telepon=?');
					$result->execute([$_SESSION['telepon']]);
					foreach ($result as $row)
						if ($row['nilaiwpt']=== NULL && $row['nilaiCfit'] === NULL ) {?>
							<div class="row">
								<a href="wptsample.php" class="waves-effect waves-light btn col s10 push-s1">Wonderlic Personnel Test (WPT)</a>
							</div>
							<div class="row">
								<a href="ciftsample.php" class="waves-effect waves-light btn col s10 push-s1" disabled>Culture Fair Intelligent Test (CFIT)</a>
							</div>
						<?php  }
						if ( $row['nilaiwpt']!== NULL && $row['nilaiCfit'] === NULL ) {?>
							<div class="row">
								<a href="wptsample.php" class="waves-effect waves-light btn col s10 push-s1" disabled>Wonderlic Personnel Test (WPT)</a>
							</div>
							<div class="row">
								<a href="ciftsample.php" class="waves-effect waves-light btn col s10 push-s1" >Culture Fair Intelligent Test (CFIT)</a>
							</div>
						<?php }
				 		if ($row['nilaiwpt'] !== NULL && $row['nilaiCfit'] !== NULL ) {?>
				 			<div class="row">
								<a href="wptsample.php" class="waves-effect waves-light btn col s10 push-s1" disabled>Wonderlic Personnel Test (WPT)</a>
							</div>
							<div class="row">
								<a href="ciftsample.php" class="waves-effect waves-light btn col s10 push-s1" disabled>Culture Fair Intelligent Test (CFIT)</a>
							</div>
							<p>You've done the whole test.</p>
						<?php } ?>
					
				</div>
			</div>
		</div>
	</div>
</div>
</section>

<?php require_once('inc/footer.inc.php'); ?>
